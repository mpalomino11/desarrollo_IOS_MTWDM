//
//  ViewController.h
//  AppArrayController
//
//  Created by Felipe Hernandez on 06/03/21.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController

@property NSMutableArray *persona;

@end

