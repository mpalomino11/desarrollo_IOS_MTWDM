//
//  LogicaNegocio.h
//  appConociendoAppkit
//
//  Created by Felipe Hernandez on 13/02/21.
//

#import <Foundation/Foundation.h>



@interface LogicaNegocio : NSObject

-(NSString *) mandarResultadoMsg;

@end


