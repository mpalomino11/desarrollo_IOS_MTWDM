//
//  ViewController.h
//  AppOperacionesNSAlertTryCatch
//
//  Created by Felipe Hernandez on 13/02/21.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController
@property (strong) IBOutlet NSTextField *txtNum1;
@property (strong) IBOutlet NSTextField *txtNum2;
@property (strong) IBOutlet NSTextField *lblResultado;
- (IBAction)onAceptar:(id)sender;


@end

