//
//  Operaciones.m
//  AppOperacionesNSAlertTryCatch
//
//  Created by Felipe Hernandez on 13/02/21.
//

#import "Operaciones.h"

@implementation Operaciones

-(int) sumar:(int)a andDos:(int)b{
    return a + b;
}


@end
