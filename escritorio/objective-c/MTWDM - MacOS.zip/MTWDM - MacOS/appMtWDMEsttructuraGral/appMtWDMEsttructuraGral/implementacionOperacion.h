//
//  implementacionOperacion.h
//  appMtWDMEsttructuraGral
//
//  Created by Felipe Hernandez on 06/02/21.
//

#import <Foundation/Foundation.h>
#import "OperacionesBasicas.h"


@interface implementacionOperacion : NSObject<OperacionesBasicas>

-(void) imprimir;

@end


