//
//  ViewController.h
//  AppAlertas
//
//  Created by Felipe Hernandez on 13/02/21.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController
- (IBAction)onAlertas:(NSButton *)sender;


@end

