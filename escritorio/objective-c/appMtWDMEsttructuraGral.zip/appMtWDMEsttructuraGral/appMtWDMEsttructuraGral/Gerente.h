//
//  Gerente.h
//  appMtWDMEsttructuraGral
//
//  Created by Felipe Hernandez on 30/01/21.
//

#import <Foundation/Foundation.h>
#import "Persona.h"

@interface Gerente : Persona

-(void)mostrarSalario;

@end

