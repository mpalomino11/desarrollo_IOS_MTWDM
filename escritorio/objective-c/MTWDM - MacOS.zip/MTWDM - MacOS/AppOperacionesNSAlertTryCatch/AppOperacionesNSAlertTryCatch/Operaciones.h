//
//  Operaciones.h
//  AppOperacionesNSAlertTryCatch
//
//  Created by Felipe Hernandez on 13/02/21.
//

#import <Foundation/Foundation.h>


@interface Operaciones : NSObject
-(int) sumar:(int)a andDos:(int)b;
@end


