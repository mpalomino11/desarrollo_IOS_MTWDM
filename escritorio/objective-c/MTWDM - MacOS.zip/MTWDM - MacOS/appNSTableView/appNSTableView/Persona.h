//
//  Persona.h
//  appNSTableView
//
//  Created by Felipe Hernandez on 27/02/21.
//

#import <Foundation/Foundation.h>

@interface Persona : NSObject

@property NSString* Nombre;
@property NSString* Domicilio;
@property int estaCasado;

@end

