//
//  LogicaNegocio.m
//  appConociendoAppkit
//
//  Created by Felipe Hernandez on 13/02/21.
//

#import "LogicaNegocio.h"

@implementation LogicaNegocio

-(NSString *) mandarResultadoMsg{
    return  @"El resultado es 25";
}

@end
