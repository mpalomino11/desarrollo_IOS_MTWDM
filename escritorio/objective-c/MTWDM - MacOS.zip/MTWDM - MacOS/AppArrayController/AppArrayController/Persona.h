//
//  Persona.h
//  AppArrayController
//
//  Created by Felipe Hernandez on 06/03/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Persona : NSObject

@property NSString* Nombre;
@property NSString* Domicilio;

@end

NS_ASSUME_NONNULL_END
