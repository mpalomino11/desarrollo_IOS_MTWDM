//
//  ViewController.h
//  appCustomViewController
//
//  Created by Felipe Hernandez on 20/02/21.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

