//
//  NSString+PruebaCategoria.h
//  appMtWDMEsttructuraGral
//
//  Created by Felipe Hernandez on 06/02/21.
//

#import <Foundation/Foundation.h>

@interface NSString (PruebaCategoria)
-(int) contarLetraA;
-(NSString *) capitalizedString;


@end
