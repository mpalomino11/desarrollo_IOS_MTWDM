//
//  AppDelegate.h
//  AppMapas
//
//  Created by Felipe Hernandez on 06/03/21.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

