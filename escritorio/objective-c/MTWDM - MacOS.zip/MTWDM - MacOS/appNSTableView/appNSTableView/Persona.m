//
//  Persona.m
//  appNSTableView
//
//  Created by Felipe Hernandez on 27/02/21.
//

#import "Persona.h"

@implementation Persona

@synthesize Nombre = Nombre;
@synthesize Domicilio = Domicilio;
@synthesize estaCasado = estaCasado;

@end
