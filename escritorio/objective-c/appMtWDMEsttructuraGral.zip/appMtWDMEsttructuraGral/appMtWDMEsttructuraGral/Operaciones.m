//
//  Operaciones.m
//  appMtWDMEsttructuraGral
//
//  Created by Felipe Hernandez on 30/01/21.
//

#import "Operaciones.h"

@implementation Operaciones

-(void) imprimirDia:(NSString *)dia andNumero:(int) num {
    NSLog(@"Es un buen %@",dia);
}
@end
