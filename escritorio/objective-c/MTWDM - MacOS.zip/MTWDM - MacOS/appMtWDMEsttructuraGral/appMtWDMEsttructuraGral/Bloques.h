//
//  Bloques.h
//  appMtWDMEsttructuraGral
//
//  Created by Felipe Hernandez on 06/02/21.
//

#import <Foundation/Foundation.h>



@interface Bloques : NSObject

-(void) variasOperaciones:(int)a andSegundo:(int)b andTipo:(int)tipo;
-(void) bloqueDentroFuncion;
-(void) division;
-(void) imprimirNombre;

@end


