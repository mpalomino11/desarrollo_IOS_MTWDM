//
//  ContentView.swift
//  app1
//
//  Created by Felipe Hernandez on 20/02/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
            .foregroundColor(.red)
            .multilineTextAlignment(.center)
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
